import os
from pathlib import Path

__project__ = 'kMap.py'
__version__ = '1.22.1'
__date__ = '19.10.2021'
__directory__ = Path(os.path.dirname(os.path.realpath(__file__)))
