import os
from pathlib import Path

__project__ = 'kMap.py'
__version__ = '1.12.0'
__date__ = '01.02.2021'
__directory__ = Path(os.path.dirname(os.path.realpath(__file__)))