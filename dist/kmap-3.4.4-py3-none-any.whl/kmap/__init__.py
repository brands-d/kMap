import os
from pathlib import Path

__project__ = "kMap.py"
__version__ = "3.4.4"
__date__ = "27.01.2025"
__directory__ = Path(os.path.dirname(os.path.realpath(__file__)))
