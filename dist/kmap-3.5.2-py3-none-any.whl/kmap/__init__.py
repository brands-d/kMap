import os
from pathlib import Path

__project__ = "kMap.py"
__version__ = "3.5.2"
__date__ = "15.07.2025"
__directory__ = Path(os.path.dirname(os.path.realpath(__file__)))
