import os
from pathlib import Path

__project__ = 'kMap.py'
__version__ = '1.13.1'
__date__ = '02.02.2021'
__directory__ = Path(os.path.dirname(os.path.realpath(__file__)))