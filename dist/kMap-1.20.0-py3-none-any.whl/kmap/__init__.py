import os
from pathlib import Path

__project__ = 'kMap.py'
__version__ = '1.20.0'
__date__ = '10.09.2021'
__directory__ = Path(os.path.dirname(os.path.realpath(__file__)))
