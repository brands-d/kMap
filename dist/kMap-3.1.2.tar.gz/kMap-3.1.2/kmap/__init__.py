import os
from pathlib import Path

__project__ = "kMap.py"
__version__ = "3.1.2"
__date__ = "07.12.2023"
__directory__ = Path(os.path.dirname(os.path.realpath(__file__)))
