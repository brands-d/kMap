import os
from pathlib import Path

__project__ = 'kMap.py'
__version__ = '1.6.1'
__date__ = '29.11.2020'
__directory__ = Path(os.path.dirname(os.path.realpath(__file__)))